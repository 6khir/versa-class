(function bootTheme() {
  try {
    const theme = localStorage.getItem('versa-theme');
    if (theme === 'dark' || theme === 'light') {
      document.documentElement.setAttribute('data-theme', theme);
      document.documentElement.style.colorScheme = theme;
    }
  } catch {}
})();
